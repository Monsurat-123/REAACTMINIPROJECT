import "./App.css";

export default function App() {
  return <div className="asst">"Hello World"</div>;
}
